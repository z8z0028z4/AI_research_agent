import os
import pandas as pd
from config import REGISTRY_EXPERIMENT_PATH

# 欄位順序定義
METADATA_EXPERIMENT_COLUMNS = [
    "tracing_number", "filename", "date", "goal", "materials",
    "procedure", "result", "comment", "type"
]

def append_experiment_metadata_to_registry(metadata: dict):
    os.makedirs(os.path.dirname(REGISTRY_EXPERIMENT_PATH), exist_ok=True)

    # 如果檔案已存在，先讀取檢查是否重複
    if os.path.exists(REGISTRY_EXPERIMENT_PATH):
        df = pd.read_excel(REGISTRY_EXPERIMENT_PATH)
        if str(metadata["tracing_number"]) in df["tracing_number"].astype(str).values:
            print(f"⚠️ Tracing number {metadata['tracing_number']} 已存在，跳過寫入。")
            return
    else:
        df = pd.DataFrame(columns=METADATA_EXPERIMENT_COLUMNS)

    # 新增這筆 metadata
    new_row = {col: metadata.get(col, "") for col in METADATA_EXPERIMENT_COLUMNS}
    df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)

    try:
        df.to_excel(REGISTRY_EXPERIMENT_PATH, index=False)
        print(f"✅ 已寫入 metadata：{metadata['new_filename']}")
    except Exception as e:
        print(f"❌ 寫入 Excel 時失敗：{e}")


if __name__ == "__main__":
    # 範例測試
    sample_metadata = {
        "tracing_number": "005",
        "filename" : "test.txt",
        "date": "20250706",
        "goal": "Test goal",
        "materials": "Material A + B",
        "procedure": "Mix and heat",
        "result": "Crystal formed",
        "comment	": "Success",
        "type": "experiment"
    }
    append_experiment_metadata_to_registry(sample_metadata)